from flask import Flask, request, jsonify
import pandas as pd
import numpy as np
from flask_cors import CORS
import google.generativeai as genai
import requests
from pymongo import MongoClient
from sklearn.ensemble import RandomForestRegressor

app = Flask(__name__)
CORS(app)

# Google Gemini AI configuration
genai.configure(api_key='AIzaSyDUUsTEvKKRya7u46jEJw4OMwFZ3dRKIRs')

# MongoDB Atlas Vector Search configuration
mongo_client = MongoClient("mongodb+srv://devan041095:MdPjPvmNZFhXQduP@cluster0.stq7u.mongodb.net/")
db = mongo_client['inventory_db']
stores_inventory_collection= db["stores_inventory"]
inventory_collection = db['inventory']
sales_collection = db['sales']

# Cosmocloud API configuration
COSMO_API_KEY = '670d392559c9b368f802b76c'
COSMO_BASE_URL = 'https://api.cosmocloud.com'
headers = {
    'Authorization': f'Bearer {COSMO_API_KEY}',
    'Content-Type': 'application/json',
}

# Helper to fetch data from Cosmocloud API
def fetch_cosmocloud_data(endpoint):
    url = f'{COSMO_BASE_URL}/{endpoint}'
    response = requests.get(url, headers=headers)
    return response.json()

def convert_objectid_to_str(data):
    if isinstance(data, list):
        return [{**item, '_id': str(item['_id'])} if '_id' in item else item for item in data]
    elif isinstance(data, dict):
        return {**data, '_id': str(data['_id'])} if '_id' in data else data
    return data

# Fetch store data from MongoDB Atlas
def get_store_data():
    store_data = list(stores_inventory_collection.find({}))
    store_data = convert_objectid_to_str(store_data)
    return pd.DataFrame(store_data)

def get_inventory_data():
    store_data = list(inventory_collection.find({}))
    store_data = convert_objectid_to_str(store_data)
    return pd.DataFrame(store_data)

# Fetch sales data from MongoDB Atlas
def fetch_sales_data():
    sales_data = list(sales_collection.find({}))
    sales_data = convert_objectid_to_str(sales_data)
    return pd.DataFrame(sales_data)

# Fetch store data and return it in JSON format
@app.route('/api/stores', methods=['GET'])
def get_stores():
    store_data = get_store_data()  # Fetch store data from MongoDB
    return jsonify(store_data.to_dict(orient='records'))

@app.route('/api/get_sales_data', methods=['GET'])
def get_sales_data():
    sales_data = list(sales_collection.find({}))  # Fetch all sales data from MongoDB
    sales_data = convert_objectid_to_str(sales_data)  # Convert ObjectId to string for frontend
    
    # Format sales data to match the expected structure in the frontend
    formatted_sales_data = [
        [
            item.get('sale_id'),         # Corresponds to sale identifier (or _id)
            item.get('Product_ID'),      # Product ID
            item.get('Product_Name'),    # Product Name
            item.get('Sales')            # Sales amount
        ]
        for item in sales_data
    ]
    
    return jsonify(formatted_sales_data)

@app.route('/api/get_inventory', methods=['GET'])
def get_inventorys():
    return get_inventory()

# Fetch inventory data from MongoDB and format it for frontend use
@app.route('/api/inventory', methods=['GET'])
def get_inventory():
    inventory_data = get_inventory_data()  # Fetch inventory data from MongoDB
    
    # Transform the data to match the frontend's expected format
    formatted_inventory = [
        [
            item.get('product_id'),       # Corresponds to item[0]: Product ID
            item.get('product_name'),     # Corresponds to item[1]: Product Name
            item.get('current_stock'),    # Corresponds to item[2]: Current Stock
            item.get('adjusted_stock')    # Corresponds to item[3]: Adjusted Stock
        ]
        for item in inventory_data.to_dict(orient='records')
    ]
    
    return jsonify(formatted_inventory)


# Function to get reallocation recommendation using Google Gemini AI
def get_reallocation_recommendation(store_id, excess_inventory, demand):
    prompt = (
        f"Given the store ID {store_id} with an excess inventory of {excess_inventory} "
        f"and a demand of {demand}, provide a stock reallocation recommendation."
    )
    try:
        model = genai.GenerativeModel("gemini-1.5-flash")
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        return f"Error in recommendation: {str(e)}"

# Route to handle stock reallocation
@app.route('/api/reallocate_stock', methods=['POST'])
def reallocate_stock():
    store_data = get_store_data()  # Fetch store data from MongoDB
    store_data['excess_inventory'] = store_data['inventory'] - store_data['demand']
    
    reallocation_decisions = []
    
    for index, row in store_data.iterrows():
        if row['excess_inventory'] > 0:
            nearby_stores = store_data[
                (store_data['demand'] > store_data['inventory']) &
                (np.abs(row['location_x'] - store_data['location_x']) < 1) &
                (np.abs(row['location_y'] - store_data['location_y']) < 1)
            ]
            for _, nearby_row in nearby_stores.iterrows():
                if nearby_row['inventory'] > 0:
                    amount_to_reallocate = min(row['excess_inventory'], nearby_row['demand'])

                    # Calculate profit if reallocation occurs
                    profit = (nearby_row['price_per_unit'] - row['price_per_unit']) * amount_to_reallocate
                    
                    recommendation = get_reallocation_recommendation(row['store_id'], amount_to_reallocate, nearby_row['demand'])
                    
                    reallocation_decisions.append({
                        'from_store': row['store_id'],
                        'to_store': nearby_row['store_id'],
                        'from_store_name': row['store_name'],
                        'to_store_name': nearby_row['store_name'],
                        'brand': row['brand'],
                        'amount': amount_to_reallocate,
                        'recommendation': recommendation,
                        'profit': profit
                    })

                    # Update inventories in MongoDB
                    inventory_collection.update_one(
                        {'store_id': row['store_id']},
                        {'$inc': {'inventory': -amount_to_reallocate}}
                    )
                    inventory_collection.update_one(
                        {'store_id': nearby_row['store_id']},
                        {'$inc': {'inventory': amount_to_reallocate}}
                    )
                    
                    # Break after one reallocation per store
                    break

    return jsonify(reallocation_decisions)

# Route to predict demand using Google Gemini AI or locally trained RandomForest model
@app.route('/api/predict-demand', methods=['POST'])
def predict_demand_route():
    data = request.json
    product_id = data['product_id']
    sales = data['sales']
    price = data['price']
    new_data = pd.DataFrame({'product_id': [product_id], 'sales': [sales], 'price': [price]})
    
    sales_data = fetch_sales_data()  # Fetch sales data from MongoDB Atlas
    model = train_demand_forecasting_model(sales_data)  # Train model locally
    prediction = predict_demand(model, new_data)
    return jsonify({'predicted_demand': prediction.tolist()})

# Function to train demand forecasting model using RandomForest
def train_demand_forecasting_model(sales_data):
    X = sales_data[['product_id', 'sales', 'price']]
    y = sales_data['sales']

    model = RandomForestRegressor()
    model.fit(X, y)
    return model

# Function to predict demand using the trained model
def predict_demand(model, new_data):
    return model.predict(new_data)

if __name__ == '__main__':
    app.run(debug=True)
